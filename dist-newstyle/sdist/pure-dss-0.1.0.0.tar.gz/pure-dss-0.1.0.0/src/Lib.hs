module Lib
    ( someFunc
    ) where

import Stack

someFunc :: IO ()
someFunc = putStrLn "someFunc"
